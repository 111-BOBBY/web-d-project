const express = require("express");
const Profile = require("../models/Profile");
const auth = require("../middleware/auth");
const router = express.Router();

// POST /api/profiles
router.post("/", auth, async (req, res) => {
  const { bio, skills, github, linkedin } = req.body;
  const profileFields = {
    user: req.user.id,
    bio,
    skills: skills?.split(",").map((skill) => skill.trim()),
    github,
    linkedin,
  };

  try {
    let profile = await Profile.findOne({ user: req.user.id });
    if (profile) {
      profile = await Profile.findOneAndUpdate(
        { user: req.user.id },
        { $set: profileFields },
        { new: true }
      );
      return res.json(profile);
    }

    profile = new Profile(profileFields);
    await profile.save();
    res.json(profile);
  } catch (err) {
    res.status(500).send("Server error");
  }
});

// GET /api/profiles?skill=node
router.get("/", async (req, res) => {
  const { skill } = req.query;
  let query = {};

  if (skill) query.skills = { $regex: new RegExp(skill, "i") };

  try {
    const profiles = await Profile.find(query).populate("user", [
      "name",
      "email",
    ]);
    res.json(profiles);
  } catch (err) {
    res.status(500).send("Server error");
  }
});

// GET /api/profiles/:id
router.get("/:id", async (req, res) => {
  try {
    const profile = await Profile.findById(req.params.id).populate("user", [
      "name",
      "email",
    ]);
    if (!profile) return res.status(404).json({ msg: "Profile not found" });
    res.json(profile);
  } catch (err) {
    res.status(500).send("Server error");
  }
});

module.exports = router;
