import React, { useState, useContext } from "react";
import axios from "axios";
import { AuthContext } from "../AuthContext";

const ProfileForm = () => {
  const { token } = useContext(AuthContext);
  const [form, setForm] = useState({
    bio: "",
    skills: "",
    github: "",
    linkedin: "",
  });

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("/api/profiles", form, {
      headers: { Authorization: `Bearer ${token}` },
    });
    alert("Profile saved!");
  };

  return (
    <form onSubmit={handleSubmit} className="p-4">
      <textarea name="bio" placeholder="Bio" onChange={handleChange}></textarea>
      <input
        name="skills"
        placeholder="Skills (comma-separated)"
        onChange={handleChange}
      />
      <input name="github" placeholder="GitHub URL" onChange={handleChange} />
      <input
        name="linkedin"
        placeholder="LinkedIn URL"
        onChange={handleChange}
      />
      <button type="submit">Save Profile</button>
    </form>
  );
};

export default ProfileForm;
