import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const ProfilesList = () => {
  const [profiles, setProfiles] = useState([]);
  const [skill, setSkill] = useState("");

  const fetchProfiles = async () => {
    const res = await axios.get(
      `/api/profiles${skill ? "?skill=" + skill : ""}`
    );
    setProfiles(res.data);
  };

  useEffect(() => {
    fetchProfiles();
  }, [skill]);

  return (
    <div className="p-4">
      <input
        placeholder="Search by skill"
        onChange={(e) => setSkill(e.target.value)}
        className="mb-4"
      />
      {profiles.map((profile) => (
        <div key={profile._id} className="border p-2 mb-2">
          <h2>{profile.user.name}</h2>
          <p>{profile.bio}</p>
          <p>Skills: {profile.skills.join(", ")}</p>
          <Link to={`/profiles/${profile._id}`}>View</Link>
        </div>
      ))}
    </div>
  );
};

export default ProfilesList;
