import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

const ViewProfile = () => {
  const { id } = useParams();
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    const fetch = async () => {
      const res = await axios.get(`/api/profiles/${id}`);
      setProfile(res.data);
    };
    fetch();
  }, [id]);

  if (!profile) return <p>Loading...</p>;

  return (
    <div className="p-4">
      <h1>{profile.user.name}</h1>
      <p>{profile.bio}</p>
      <p>Skills: {profile.skills.join(", ")}</p>
      <p>
        GitHub: <a href={profile.github}>{profile.github}</a>
      </p>
      <p>
        LinkedIn: <a href={profile.linkedin}>{profile.linkedin}</a>
      </p>
    </div>
  );
};

export default ViewProfile;
