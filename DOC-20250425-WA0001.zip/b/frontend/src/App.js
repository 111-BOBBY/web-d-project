import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./AuthContext";
import Navbar from "./components/Navbar";
import Register from "./pages/Register";
import Login from "./pages/Login";
import ProfileForm from "./pages/ProfileForm";
import ProfilesList from "./pages/ProfilesList";
import ViewProfile from "./pages/ViewProfile";

function App() {
  return (
    <AuthProvider>
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<ProfilesList />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/profile" element={<ProfileForm />} />
          <Route path="/profiles/:id" element={<ViewProfile />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
